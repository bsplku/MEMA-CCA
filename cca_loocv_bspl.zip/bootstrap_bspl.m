%% 2020 June 09 made by Sungman Jo
% U = independent variable [n x 1]
% V = dependent variable [n x 1]
% n_iter = the number of iteration for bootstrapping
% CI = 95% upper and lower confidence interval (CI)
% You can run this file in order to draw the figures after bootstrapping n_iter times and obtain CI (95%) value [lower CI, upper CI]

function CI = bootstrap_bspl(U, V, n_iter)
tot_corr = [];
len_samp = length(U);
[r p] = corr(U(:,1),V(:,1));
for i = 1:n_iter
    idx_bs = randi([1,len_samp],1,len_samp);  % shuffle the index within the number of sample with replacement
    bs_U = U(idx_bs,1);  % a newly shuffled independent variable
    bs_V = V(idx_bs,1);  % a newly shuffled dependent variable
    
    % Pearson correlation to the new independent variable and dependent variable
    [r1 p1] = corr(bs_U(:,1),bs_V(:,1));
    
    tot_corr =[tot_corr,r1];
end

m = mean(tot_corr);  % mean of total correlation coefficients
s = std(tot_corr); % standard deviation of total correlation coefficients
CI = prctile(tot_corr,[2.5,97.5]); % 95% confidence interval

% Plot the histogram with all of the correlation coefficients from bootstrapping (n_iter)
figure();hist(tot_corr,100);set(gcf,'Color','w');
title('Sample drawn from bootstrapping');
hold on; ylim = get(gca,'Ylim'); hold on;
xlabel(sprintf('CI = [%.2f %.2f]',CI(1),CI(2)));

plot(r*[1 1],ylim*1.05);  % the estimated correlation coefficient
plot(CI(1)*[1 1], ylim*1.05,'r-','LineWidth',2);  % the lower confidence interval
plot(CI(2)*[1 1],ylim*1.05,'r-','LineWidth',2);  % the upper confidence interval

end